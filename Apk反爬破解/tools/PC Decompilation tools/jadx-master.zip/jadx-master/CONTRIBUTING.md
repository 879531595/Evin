# Contribution

To support this project you can:
  - Post thoughts about new features/optimizations that important to you
  - Submit bug using one of following patterns:
    * Java code examples which decompiles incorrectly
    * Error log and link to _public available_ apk file or app page on Google play
